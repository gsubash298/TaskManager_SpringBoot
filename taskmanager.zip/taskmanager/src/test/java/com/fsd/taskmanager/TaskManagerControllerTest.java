package com.fsd.taskmanager;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.easymock.*;
@RunWith(MockitoJUnitRunner.class)
public class TaskManagerControllerTest {
	
	@InjectMocks
	private TaskManagerController taskMngCtrl;
	@Mock
	private TaskManagerServiceImpl taskManageService;
	/*@Spy
    private TaskDao taskDaoImpl;*/
	
	private TaskManagerJSON taskManageJSON;
	private List<TaskManagerJSON> taskManageJSONList;
	private Task task;
	private ParentTask parentTask;
	private List<Task> taskList;
	private String status;
	
	@Before
    public void before() {		
		MockitoAnnotations.initMocks(this);		
		taskManageJSON = new TaskManagerJSON();
		//taskMngCtrl = new TaskManagerController();
		task = new Task();
		parentTask = new ParentTask();
		taskList = new ArrayList<Task>();
		taskManageJSONList = new ArrayList<TaskManagerJSON>();
		status = null;
		createJSONTask();
		createTaskObj();
		/*Mockito.when(taskManageService.addTask(task)).thenReturn("Added");*/
    }
	
	@Test
	public void createTask() throws Exception{			
		/*TaskDaoImpl taskDaoImpl = EasyMock.createMock(TaskDaoImpl.class);
		//EasyMock.expect(((IExpectationSetters) taskDaoImpl.getAllTask()).andReturn(taskList));
		 expect  taskMngCtrl.create(taskManageJSON);
		EasyMock.expectLastCall();
        EasyMock.replay(taskDaoImpl);*/
		//Mockito.when(taskDaoImpl.addOrMergeTask(task)).thenReturn();
		
		/*doAnswer(new Answer() {
		    public Void answer(InvocationOnMock invocation) {		      
		      return null;
		    }
		}).when(taskDaoImpl).addOrMergeTask(task);*/
		
		/*doAnswer((i) -> {			
			return null;
		}).when(taskDaoImpl).setName(anyString());*/
		
		//Mockito.doNothing().when(taskDaoImpl).addOrMergeTask(task);
		//Mockito.when(taskManageService.addTask(task)).thenReturn("Added");
		Mockito.doReturn("Added").when(this.taskManageService).addTask(this.task);
		
        status = taskMngCtrl.createTask(taskManageJSON);
        assertEquals("Added",status);		
	}
	
	@Test
	public void updateTask() throws Exception{
		Mockito.doReturn("Updated").when(this.taskManageService).updateTask(this.task);
		status = taskMngCtrl.updateTask(taskManageJSON);
        assertEquals("Updated",status);		
	}
	
	@Test
	public void deleteTask() throws Exception{
		Mockito.doReturn("Deleted").when(this.taskManageService).deleteTask(this.task);
		status = taskMngCtrl.deleteTask(task.getTaskId());
        assertEquals("Deleted",status);		
	}
	
	@Test
	public void getTaskList() throws Exception{
		Mockito.doReturn(taskList).when(this.taskManageService).getTaskList();
		taskManageJSONList = taskMngCtrl.getTaskList();
		//Assert the taskId from the taskList and taskManageJSONList
        assertEquals(taskManageJSONList.get(0).getTaskId(),taskList.get(0).getTaskId());		
	}

	private void createTaskObj() {
		//Create a task object		
		task.setTaskName(taskManageJSON.getTask());
		parentTask.setParentaskName(taskManageJSON.getParentTask());
		task.setParentTask(parentTask);
		task.setPriority(taskManageJSON.getPriority());
		task.setStartDate(new java.sql.Date(taskManageJSON.getStartDate().getTime()));
		task.setEndDate(new java.sql.Date(taskManageJSON.getEndDate().getTime()));
		taskList.add(task);
	}

	private void createJSONTask() {
		//Create a JSON Task
		taskManageJSON.setTask("Task1");
		taskManageJSON.setParentTask("ParentTaskl");
		taskManageJSON.setPriority(10);
		taskManageJSON.setStartDate(new Date());
		taskManageJSON.setEndDate(new Date());		
	}
}
