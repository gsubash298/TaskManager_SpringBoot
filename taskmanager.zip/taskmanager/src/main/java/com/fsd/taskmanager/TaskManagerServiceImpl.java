package com.fsd.taskmanager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service("TaskManagerService")
public class TaskManagerServiceImpl implements TaskManagerService {
    
	@Autowired
	TaskDao taskDaoImpl1;
	
    public String addTask(Task task) {
    	//TaskDaoImpl taskDaoImpl1 = new TaskDaoImpl();
    	taskDaoImpl1.addTask(task);
        return "Added";
    }
    
    public List<Task> retrieveTask(Task task) {
    	List<Task> taskList = null;
    	taskList = taskDaoImpl1.getTaskbyTaskName(task.getTaskName());    	
        return taskList;
    }
    
    public String deleteTask(Task task) {  
    	
    	taskDaoImpl1.deleteTask(task);    	
        return "Deleted";
    } 
    
    /*public String deleteTask(int taskId) { 
    	Task task=taskDaoImpl1.getTaskByID(taskId);
    	if(null!=task )
    	taskDaoImpl1.deleteTask(task);    	
       
    	return "Deleted";
    }*/
}
