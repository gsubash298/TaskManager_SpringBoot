package com.fsd.taskmanager;

public interface TaskManagerService {

	String addTask(Task task);
}
