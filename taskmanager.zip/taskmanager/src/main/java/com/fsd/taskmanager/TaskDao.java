package com.fsd.taskmanager;

import java.util.List;
import com.fsd.taskmanager.Task;
 
public interface TaskDao{
	/**
	 * This method is to add or merge the task from DB
	 * @param task
	 */
	void addOrMergeTask(Task task);
	
    /**
     * This method is to delete the task  from DB
     * @param task
     */
    void deleteTask(Task task);	
	
	/**
	 * This method is to get the list of task from DB
	 * @return
	 */
	List<Task> getAllTask();

}