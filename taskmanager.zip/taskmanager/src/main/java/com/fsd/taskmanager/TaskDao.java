package com.fsd.taskmanager;

 

import java.sql.Date;

import java.util.List;

 

import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.fsd.taskmanager.ParentTask;

import com.fsd.taskmanager.Task;

 
/*@Repository*/
public interface TaskDao{

               

               

                void addTask(Task task);
                
                void updateTask(Task task);
                
                List<Task> getTaskbyTaskName(String taskName);
                
                void deleteTask(Task task);

            Task getTaskByID(int taskId);
            
            List<Task> getTask();

           /*     public ParentTask getParentTaskByID(int id);

                ParentTask getParentTaskbyName(String ParenTaskName);

                boolean isExistingTask(String taskName);

                List<Task> getTaskbyTaskName(String taskName);

                List<Task> getTasksByParentTask(String parentTaskName);

                List<Task> getTasksByPriority(int from, int to);

                List<Task> getTasksByDate(Date startDate, Date endDate);

                void updateTask(Task task);

                public void configure();

                public SessionFactory getSessionFactory();

                public Session getSession();*/

               

}