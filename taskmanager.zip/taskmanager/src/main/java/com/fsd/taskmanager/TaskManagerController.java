package com.fsd.taskmanager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping({"/taskManager"})
public class TaskManagerController {

    @Autowired
    private TaskManagerServiceImpl taskManageService;
    
    @PostMapping
    public TaskManagerJSON create(@RequestBody TaskManagerJSON taskManageJSON){
    	
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	
    	
    	//setting the JSON object to the the task and parent task bean
    	task.setTaskName(taskManageJSON.getTask());
    	
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(taskManageJSON.getParentTask());
    	
    	java.sql.Date sqlStartDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(taskManageJSON.getPriority());
    	
    	taskManageService.addTask(task);
    	
		return taskManageJSON;
        
    }
    
    @GetMapping(path = {"/{taskNm}"})
    public TaskManagerJSON retrieveTask(String taskNm){    	
    	
    	Task task = new Task();
    	
    	TaskManagerJSON taskManageJSON = new TaskManagerJSON();
    	task.setTaskName(taskNm);    	
    	
    	List<Task> listOfTask = taskManageService.retrieveTask(task);
    	
    	for (Task task1: listOfTask){
    		taskManageJSON.setTask(task1.getTaskName());
    		taskManageJSON.setPriority(task1.getPriority());
    		taskManageJSON.setParentTask(task1.getParentTask().getParentaskName());
    		taskManageJSON.setStartDate(task1.getStartDate());
    		taskManageJSON.setEndDate(task1.getEndDate());
    		taskManageJSON.setParentId(task1.getParentTask().getParentId());
    		taskManageJSON.setTaskId(task1.getTaskId());
    	}    	    	
		return taskManageJSON;
        
    }
    
    @DeleteMapping(path ={"/{taskId}"})
    public String deleteTask(int taskId) {
    	Task task = new Task();    	
    	task.setTaskId(taskId);
    	taskManageService.deleteTask(task);
    	//taskManageService.deleteTask(taskId);
    	return "deleted";
    }
    
}
