package com.fsd.taskmanager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600, allowedHeaders="*")
@RestController
@RequestMapping({"/taskManager"})
public class TaskManagerController {

    @Autowired
    private TaskManagerServiceImpl taskManageService;
    
    private String status = null;
        
    /**
     * This method is to create the task
     * @param taskManageJSON
     * @return
     * @throws ParseException
     */
    @PostMapping
    public String createTask(@RequestBody TaskManagerJSON taskManageJSON) throws ParseException{
    	
    	//Create task and parent task entity object
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	
    	//setting the JSON object to the the task and parent task bean
    	task.setTaskName(taskManageJSON.getTask());
    	
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(taskManageJSON.getParentTask());
    	    	
    	//Get the sql date from the util date object
    	java.sql.Date sqlStartDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(taskManageJSON.getPriority());
    	//Call the add task method
    	status = taskManageService.addTask(task);
    	
		return status;
    }
    
    /**
     * This method is to derive the list of task
     * @return taskManageJSONList
     */
    @GetMapping
    public List<TaskManagerJSON> getTaskList(){    	
    	//Create taskManagerJSON list object
    	List<TaskManagerJSON> taskManageJSONList = new ArrayList<TaskManagerJSON>();    	
    	List<Task> listOfTask = taskManageService.getTaskList();
    	
    	for (Task task: listOfTask){
    		TaskManagerJSON taskManageJSON = new TaskManagerJSON();
    		taskManageJSON.setTaskId(task.getTaskId());
    		taskManageJSON.setTask(task.getTaskName());
    		taskManageJSON.setPriority(task.getPriority());    		    		
    		taskManageJSON.setStartDate(task.getStartDate());
    		taskManageJSON.setEndDate(task.getEndDate());
    		if(task.getParentTask() != null) {
    			taskManageJSON.setParentId(task.getParentTask().getParentId());
    			taskManageJSON.setParentTask(task.getParentTask().getParentaskName());
    		}    		
    		taskManageJSONList.add(taskManageJSON);
    	}    	    	
		return taskManageJSONList;        
    }
    
    @PutMapping
    public String updateTask(@RequestBody TaskManagerJSON taskManageJSON) throws ParseException{
    	
    	//Create task and parent task entity object
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	
    	//setting the JSON object to the the task and parent task bean
    	task.setTaskName(taskManageJSON.getTask());
    	task.setTaskId(taskManageJSON.getTaskId());    	
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(taskManageJSON.getParentTask());
    	task.getParentTask().setParentId(taskManageJSON.getParentId());
    	
    	java.sql.Date sqlStartDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(taskManageJSON.getPriority());
    	
    	status = taskManageService.updateTask(task);
    	
		return status;
        
    }
    
    @DeleteMapping(path ={"/{taskId}"})
    public String deleteTask(int taskId) {
    	Task task = new Task();    	
    	task.setTaskId(taskId);
    	
    	status = taskManageService.deleteTask(task);
    	return status;
    }
    
}
