package com.fsd.taskmanager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600, allowedHeaders="*")
@RestController
@RequestMapping({"/taskManager"})
public class TaskManagerController {

    @Autowired
    private TaskManagerServiceImpl taskManageService;
    
    @PostMapping
    public TaskManagerJSON create(@RequestBody TaskManagerJSON taskManageJSON) throws ParseException{
    	
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	
    	
    	//setting the JSON object to the the task and parent task bean
    	task.setTaskName(taskManageJSON.getTask());
    	
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(taskManageJSON.getParentTask());
    	
    	/*SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
    	java.util.Date date = sdf1.parse(taskManageJSON.getStartDate());
    	java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
    	
    	java.util.Date enddate = sdf1.parse(taskManageJSON.getEndDate());
    	java.sql.Date sqlEndDate = new java.sql.Date(enddate.getTime());*/
    	
    	java.sql.Date sqlStartDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(taskManageJSON.getPriority());
    	
    	taskManageService.addTask(task);
    	
		return taskManageJSON;
        
    }
    
    @GetMapping(path = {"/{taskNm}"})
    public TaskManagerJSON retrieveTask(String taskNm){    	
    	
    	Task task = new Task();
    	
    	TaskManagerJSON taskManageJSON = new TaskManagerJSON();
    	task.setTaskName(taskNm);    	
    	
    	List<Task> listOfTask = taskManageService.retrieveTask(task);
    	
    	for (Task task1: listOfTask){
    		taskManageJSON.setTask(task1.getTaskName());
    		taskManageJSON.setPriority(task1.getPriority());
    		taskManageJSON.setParentTask(task1.getParentTask().getParentaskName());
    		//taskManageJSON.setStartDate(task1.getStartDate());
    		//taskManageJSON.setEndDate(task1.getEndDate());
    		taskManageJSON.setParentId(task1.getParentTask().getParentId());
    		taskManageJSON.setTaskId(task1.getTaskId());
    	}    	    	
		return taskManageJSON;
        
    }
    
    @GetMapping
    public List<TaskManagerJSON> getTaskList(){    	
    	
    	List<TaskManagerJSON> taskManageJSONList = new ArrayList<TaskManagerJSON>();    	
    	List<Task> listOfTask = taskManageService.getTaskList();
    	
    	for (Task task1: listOfTask){
    		TaskManagerJSON taskManageJSON = new TaskManagerJSON();
    		taskManageJSON.setTask(task1.getTaskName());
    		taskManageJSON.setPriority(task1.getPriority());
    		taskManageJSON.setParentTask(task1.getParentTask().getParentaskName());
    		taskManageJSON.setStartDate(task1.getStartDate());
    		taskManageJSON.setEndDate(task1.getEndDate());
    		taskManageJSON.setParentId(task1.getParentTask().getParentId());
    		taskManageJSON.setTaskId(task1.getTaskId());
    		taskManageJSONList.add(taskManageJSON);
    	}    	    	
		return taskManageJSONList;
        
    }
    
    @PutMapping
    public String update(@RequestBody TaskManagerJSON taskManageJSON) throws ParseException{
    	
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	
    	
    	//setting the JSON object to the the task and parent task bean
    	task.setTaskName(taskManageJSON.getTask());
    	
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(taskManageJSON.getParentTask());
    	
    	/*SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
    	java.util.Date date = sdf1.parse(taskManageJSON.getStartDate());
    	java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
    	
    	java.util.Date enddate = sdf1.parse(taskManageJSON.getEndDate());
    	java.sql.Date sqlEndDate = new java.sql.Date(enddate.getTime());*/
    	
    	java.sql.Date sqlStartDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(taskManageJSON.getPriority());
    	
    	taskManageService.updateTask(task);
    	
		return "UPDATED SUCCESSFULLY";
        
    }
    
    @DeleteMapping(path ={"/{taskId}"})
    public String deleteTask(int taskId) {
    	Task task = new Task();    	
    	task.setTaskId(taskId);
    	taskManageService.deleteTask(task);
    	//taskManageService.deleteTask(taskId);
    	return "deleted";
    }
    
}
