package com.fsd.taskmanager;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import com.fsd.taskmanager.controller.TaskManagerController;
import com.fsd.taskmanager.controller.TaskManagerJSON;
import com.fsd.taskmanager.dao.ParentTask;
import com.fsd.taskmanager.dao.Task;
import com.fsd.taskmanager.service.TaskManagerServiceImpl;
@RunWith(MockitoJUnitRunner.class)
public class TaskManagerControllerTest {
	
	@InjectMocks
	private TaskManagerController taskMngCtrl;
	@Mock
	private TaskManagerServiceImpl taskManageService;

	private BindingResult bindingResult;
	private TaskManagerJSON taskManageJSON;
	private List<TaskManagerJSON> taskManageJSONList;
	private Task task;
	private ParentTask parentTask;
	private List<Task> taskList;
	private ResponseEntity<Object> statusObj;
	private ResponseEntity<Integer> statusInt;
	private ResponseEntity<TaskManagerJSON> status;
	
	@Before
    public void before() {		
		MockitoAnnotations.initMocks(this);		
		taskManageJSON = new TaskManagerJSON();
		task = new Task();
		parentTask = new ParentTask();
		taskList = new ArrayList<Task>();
		taskManageJSONList = new ArrayList<TaskManagerJSON>();
		bindingResult = null;
		status = null;
		statusObj = null;
		statusInt = null;
		createJSONTask();
		createTaskObj();
    }
	
	@Test
	public void createTask() throws Exception{			
		Mockito.doReturn("Added").when(this.taskManageService).addTask(this.task);
        statusObj = taskMngCtrl.createTask(taskManageJSON, bindingResult);
        assertEquals(200,statusObj.getStatusCode().value());		
	}
	
	@Test
	public void updateTask() throws Exception{
		Mockito.doReturn("Updated").when(this.taskManageService).updateTask(this.task);
		status = taskMngCtrl.updateTask(taskManageJSON);
        assertEquals(200,status.getStatusCode().value());		
	}
	
	@Test
	public void deleteTask() throws Exception{
		Mockito.doReturn("Deleted").when(this.taskManageService).deleteTask(this.task);
		statusInt = taskMngCtrl.deleteTask(task.getTaskId());
        assertEquals(200,statusInt.getStatusCode().value());		
	}
	
	@Test
	public void getTaskList() throws Exception{
		Mockito.doReturn(taskList).when(this.taskManageService).getTaskList();
		taskManageJSONList = taskMngCtrl.getTaskList();
        assertEquals(taskManageJSONList.get(0).getTaskId(),taskList.get(0).getTaskId());		
	}

	private void createTaskObj() {
		//Create a task object		
		task.setTaskName(taskManageJSON.getTask());
		parentTask.setParentaskName(taskManageJSON.getParentTask());
		task.setParentTask(parentTask);
		task.setPriority(taskManageJSON.getPriority());
		task.setStartDate(new java.sql.Date(taskManageJSON.getStartDate().getTime()));
		task.setEndDate(new java.sql.Date(taskManageJSON.getEndDate().getTime()));
		taskList.add(task);
	}

	private void createJSONTask() {
		//Create a JSON Task
		taskManageJSON.setTask("Task1");
		taskManageJSON.setParentTask("ParentTaskl");
		taskManageJSON.setPriority(10);
		taskManageJSON.setStartDate(new Date());
		taskManageJSON.setEndDate(new Date());		
	}
}
