package com.fsd.taskmanager.service;

import java.util.List;

import com.fsd.taskmanager.dao.Task;

public interface TaskManagerService {
	String addTask(Task task);
	String updateTask(Task task);
	List<Task> getTaskList();
	String deleteTask(Task task);
	Task getMatchingTask(Task task);
}
