package com.fsd.taskmanager.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.fsd.taskmanager.exception.ExceptionResponse;
import com.fsd.taskmanager.exception.UserException;

@ControllerAdvice
public class ErrorManagerController {
	
	private static final Logger log = LoggerFactory.getLogger(ErrorManagerController.class);
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ExceptionResponse> genericException(Exception e) throws Exception {
		
		ExceptionResponse expRes = new ExceptionResponse();
		expRes.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		expRes.setDescription("Something went wrong in taskManager");
		log.debug(e.toString());
		return new ResponseEntity<ExceptionResponse>(expRes,HttpStatus.INTERNAL_SERVER_ERROR);		
	}
	
	@ExceptionHandler(UserException.class)
	public ResponseEntity<ExceptionResponse> userException(UserException e) throws Exception {
		
		ExceptionResponse expRes = new ExceptionResponse();
		expRes.setCode(e.getCode());
		expRes.setDescription(e.getMessage());
		log.debug(e.toString());
		return new ResponseEntity<ExceptionResponse>(expRes,HttpStatus.INTERNAL_SERVER_ERROR);		
	}
}
