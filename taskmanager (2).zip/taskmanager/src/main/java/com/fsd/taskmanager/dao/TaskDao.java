package com.fsd.taskmanager.dao;

import java.util.List;
 
public interface TaskDao{
	/**
	 * This method is to add or merge the task from DB
	 * @param task
	 */
	void addOrMergeTask(Task task);
	
    /**
     * This method is to delete the task  from DB
     * @param task
     */
    void deleteTask(Task task);	
	
	/**
	 * This method is to get the list of task from DB
	 * @return
	 */
	List<Task> getAllTask();
	
	/**
	 * This method is to get the matching list of task from DB
	 * @return
	 */
	Task getMatchingTask(Task task);

}