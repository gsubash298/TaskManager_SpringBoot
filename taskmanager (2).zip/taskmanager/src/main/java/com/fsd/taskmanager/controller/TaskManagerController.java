package com.fsd.taskmanager.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import com.fsd.taskmanager.dao.ParentTask;
import com.fsd.taskmanager.dao.Task;
import com.fsd.taskmanager.exception.ExceptionResponse;
import com.fsd.taskmanager.exception.UserException;
import com.fsd.taskmanager.service.TaskManagerServiceImpl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600, allowedHeaders="*")
@RestController
@RequestMapping({"/taskManager"})
public class TaskManagerController {
	
	private static final Logger log = LoggerFactory.getLogger(TaskManagerController.class);
    @Autowired
    private TaskManagerServiceImpl taskManageService;
    
    private String status = null;
    
    private Map<String,String> validationList;
        
    /**
     * This method is to create the task
     * @param taskManageJSON
     * @return
     * @throws ParseException
     */
    @PostMapping
    public ResponseEntity<Object> createTask(@RequestBody @Valid TaskManagerJSON taskManageJSON, BindingResult bindingResult) throws RuntimeException, UserException{
    	
    	log.info("Inside create Task method {}", taskManageJSON);
    	
    	if(bindingResult != null && bindingResult.hasErrors()) {
    		validationList = new HashMap<String,String>();
    		for(FieldError fieldError: bindingResult.getFieldErrors()) {
    			validationList.put(fieldError.getField(), fieldError.getDefaultMessage());
    		}
    		return new ResponseEntity<>(validationList,HttpStatus.NOT_ACCEPTABLE);
    	}
    	
    	//Create task and parent task entity object
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	
    	//setting the JSON object to the the task and parent task bean
    	task.setTaskName(taskManageJSON.getTask());
    	
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(taskManageJSON.getParentTask());
    	    	
    	//Get the sql date from the util date object
    	java.sql.Date sqlStartDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(taskManageJSON.getPriority());
    	
    	Task matchingTask = taskManageService.getMatchingTask(task);
    	
    	if (matchingTask != null) {    		
    		UserException ue = new UserException();
    		ue.setCode(HttpStatus.CONFLICT.value());
    		ue.setMessage("Task with same taskname, startDate, EndDate, priority is already existed");
    		throw ue;
    	}

    	//Call the add task method
    	status = taskManageService.addTask(task);
    	if ("Added".equals(status)) {
    		log.info("Task is created successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<>(taskManageJSON,HttpStatus.OK);
    }
    
    /**
     * This method is to derive the list of task
     * @return taskManageJSONList
     */
    @GetMapping
    public List<TaskManagerJSON> getTaskList(){    	
    	//Create taskManagerJSON list object
    	log.info("Inside getTaskList method");
    	List<TaskManagerJSON> taskManageJSONList = new ArrayList<TaskManagerJSON>();    	
    	List<Task> listOfTask = taskManageService.getTaskList();
    	for (Task task: listOfTask){
    		TaskManagerJSON taskManageJSON = new TaskManagerJSON();
    		taskManageJSON.setTaskId(task.getTaskId());
    		taskManageJSON.setTask(task.getTaskName());
    		taskManageJSON.setPriority(task.getPriority());    		    		
    		taskManageJSON.setStartDate(task.getStartDate());
    		taskManageJSON.setEndDate(task.getEndDate());
    		if(task.getParentTask() != null) {
    			taskManageJSON.setParentId(task.getParentTask().getParentId());
    			taskManageJSON.setParentTask(task.getParentTask().getParentaskName());
    		}    		
    		taskManageJSONList.add(taskManageJSON);
    	}
    	log.info("List of task retrieved: \n {}", taskManageJSONList);
		return taskManageJSONList;        
    }
    
    @PutMapping
    public ResponseEntity<TaskManagerJSON> updateTask(@RequestBody TaskManagerJSON taskManageJSON) throws ParseException{
    	
    	log.info("Inside update Task method {}", taskManageJSON);
    	//Create task and parent task entity object
    	Task task = new Task();
    	ParentTask parentTask = new ParentTask();
    	
    	//setting the JSON object to the the task and parent task bean
    	task.setTaskName(taskManageJSON.getTask());
    	task.setTaskId(taskManageJSON.getTaskId());    	
    	task.setParentTask(parentTask);
    	task.getParentTask().setParentaskName(taskManageJSON.getParentTask());
    	task.getParentTask().setParentId(taskManageJSON.getParentId());
    	
    	java.sql.Date sqlStartDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	java.sql.Date sqlEndDate = new java.sql.Date(taskManageJSON.getStartDate().getTime());
    	task.setStartDate(sqlStartDate);
    	task.setEndDate(sqlEndDate);
    	task.setPriority(taskManageJSON.getPriority());
    	
    	status = taskManageService.updateTask(task);
    	if ("Updated".equals(status)) {
    		log.info("Task is updated successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<TaskManagerJSON>(taskManageJSON,HttpStatus.OK);
    }
    
    @DeleteMapping(path ={"/{taskId}"})
    public ResponseEntity<Integer> deleteTask(int taskId) {
    	log.info("Inside delete Task method {}", taskId);
    	Task task = new Task();    	
    	task.setTaskId(taskId);
    	
    	status = taskManageService.deleteTask(task);
    	if ("Deleted".equals(status)) {
    		log.info("Task is deleted successfully --> status =  {}", status);
    	}
    	return new ResponseEntity<Integer>(taskId,HttpStatus.OK);
    }
    
}
