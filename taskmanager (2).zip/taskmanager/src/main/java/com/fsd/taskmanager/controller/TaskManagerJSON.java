package com.fsd.taskmanager.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude
public class TaskManagerJSON {

	private int taskId;	
	private int ParentId;
	@NotEmpty (message="Please enter the taskName")
	private String task;
	private String parentTask;
	@NotNull(message="Please enter the startDate")
	private Date startDate;
	@NotNull(message="Please enter the endDate")
	private Date endDate;
	@NotNull(message="Please select the Priority")
	private Integer priority;
	
	public int getTaskId() {
		return taskId;
	}
	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}
	public int getParentId() {
		return ParentId;
	}
	public void setParentId(int parentId) {
		ParentId = parentId;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getParentTask() {
		return parentTask;
	}
	public void setParentTask(String parentTask) {
		this.parentTask = parentTask;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Integer getPriority() {
		return priority;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	
	private DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
	
	public String toString(){		
		return "taskId :"+this.taskId+","+
				"ParentId :"+this.ParentId+","+
				"task :"+this.task+","+
				"parentTask :"+this.parentTask+","+
				"startDate :"+dateFormat.format(this.startDate)+","+
				"endDate :"+dateFormat.format(this.endDate)+","+
				"priority :"+this.priority+"\n";
		
	}
}
