package com.fsd.taskmanager.dao;

import java.util.List;
import javax.persistence.EntityManagerFactory;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fsd.taskmanager.dao.TaskDao;
 
@Repository("TaskDao")
public class TaskDaoImpl implements TaskDao{
	
	private static final Logger log = LoggerFactory.getLogger(TaskDaoImpl.class);
	
	@Autowired
	private EntityManagerFactory entityManagerFactory;

	/* (non-Javadoc)
	 * @see com.fsd.taskmanager.TaskDao#addOrMergeTask(com.fsd.taskmanager.Task)
	 */
	public void addOrMergeTask(Task task) {
		log.info("Inside dao method: addOrMergeTask");
		Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
		Transaction tx = session.beginTransaction();
		try {
			session.saveOrUpdate(task);
		}catch (RuntimeException e) {
			session.close();
			throw new RuntimeException("Error occured in addOrMergeTask",e);
        }finally{
        	tx.commit();
        	session.close();
        }
	}
	
	/* (non-Javadoc)
	 * @see com.fsd.taskmanager.TaskDao#deleteTask(com.fsd.taskmanager.Task)
	 */
	public void deleteTask(Task task) {
		log.info("Inside dao method: deleteTask");
	   	Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        Transaction tx = session.beginTransaction();
          
        try{
        	session.load(task, task.getTaskId());
            session.delete(task);
          }catch (Exception e) {
              session.close();
        	  throw new RuntimeException("Error occured in deleteTask",e);
          }finally{
        	  tx.commit();
        	  session.close();
          }
	}

	/* (non-Javadoc)
    * @see com.fsd.taskmanager.TaskDao#getAllTask()
    */
	public List<Task> getAllTask() {
	   log.info("Inside dao method: getAllTask");
	   Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();           
	   List<Task> taskList = null;
       try{
    	   taskList = session.createCriteria(Task.class).list();       	           	    
       }catch (Exception e) {
    	   throw new RuntimeException("Error occured in getAllTask",e);
       }    	  
       return taskList;    	   
   }
	
	/* (non-Javadoc)
	 * @see com.fsd.taskmanager.TaskDao#getMatchingTask(com.fsd.taskmanager.Task)
	 */
	public Task getMatchingTask(Task task) {
		log.info("Inside dao method: getTaskByName");
	   	Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        Transaction tx = session.beginTransaction();
          
        try{
        	
        	Criteria criteria = session.createCriteria(Task.class);
        	criteria.add(Restrictions.eq("taskName", task.getTaskName()));
        	criteria.add(Restrictions.eq("startDate", task.getStartDate()));
        	criteria.add(Restrictions.eq("endDate", task.getEndDate()));
        	criteria.add(Restrictions.eq("priority", task.getPriority()));
        	Task matchingTask = (Task) criteria.uniqueResult();
        	
        	return matchingTask;
          }catch (Exception e) {
              session.close();
        	  throw new RuntimeException("Error occured in getMatchingTask",e);
          }finally{
        	  tx.commit();
        	  session.close();
          }
	}
       
}