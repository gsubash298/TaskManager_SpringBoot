package com.fsd.taskmanager.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsd.taskmanager.dao.Task;
import com.fsd.taskmanager.dao.TaskDao;

import java.util.ArrayList;
import java.util.List;

@Service("TaskManagerService")
public class TaskManagerServiceImpl implements TaskManagerService {
    
	@Autowired
	TaskDao taskDaoImpl;
	
    /* (non-Javadoc)
     * @see com.fsd.taskmanager.TaskManagerService#addTask(com.fsd.taskmanager.Task)
     */
    public String addTask(Task task) {
    	taskDaoImpl.addOrMergeTask(task);
        return "Added";
    }
    
    /* (non-Javadoc)
     * @see com.fsd.taskmanager.TaskManagerService#updateTask(com.fsd.taskmanager.Task)
     */
    public String updateTask(Task task) {
    	taskDaoImpl.addOrMergeTask(task);
        return "Updated";
    }
    
    /* (non-Javadoc)
     * @see com.fsd.taskmanager.TaskManagerService#getTaskList()
     */
    public List<Task> getTaskList() {
    	List<Task> taskList = null;
    	taskList = taskDaoImpl.getAllTask();    	
        return taskList;
    }
    
    /* (non-Javadoc)
     * @see com.fsd.taskmanager.TaskManagerService#deleteTask(com.fsd.taskmanager.Task)
     */
    public String deleteTask(Task task) {  
    	taskDaoImpl.deleteTask(task);    	
        return "Deleted";
    }
    
    /* (non-Javadoc)
     * @see com.fsd.taskmanager.TaskManagerService#getMatchingTask(com.fsd.taskmanager.Task)
     */
    public Task getMatchingTask(Task task) {
    	Task matchingTask = taskDaoImpl.getMatchingTask(task);
    	return matchingTask;
    }
}
